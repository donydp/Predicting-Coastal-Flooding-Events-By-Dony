#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
model.py (Codabench inference)

Reads:
  /app/input_data/test_hourly.csv
  /app/input_data/test_index.csv

Loads:
  /app/ingested_program/model.pkl

Writes:
  /app/output/predictions.csv with columns: id,y_prob

Notes:
- Portable (no sklearn pickle).
- If a requested window cannot be built -> y_prob=0.5
"""

import os
import pickle
import tempfile
import numpy as np
import pandas as pd

try:
    import xgboost as xgb
    HAS_XGB = True
except Exception:
    HAS_XGB = False
    xgb = None

def logit(p):
    p = np.clip(p, 1e-6, 1.0 - 1e-6)
    return np.log(p / (1.0 - p))

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def hourly_to_daily(df_hourly):
    df = df_hourly.copy()
    df["time"] = pd.to_datetime(df["time"])
    df["date"] = df["time"].dt.floor("D")

    daily = (
        df.groupby(["station_name", "date"])
        .agg(
            sea_level=("sea_level", "mean"),
            sea_level_max=("sea_level", "max"),
            sea_level_min=("sea_level", "min"),
            sea_level_std=("sea_level", "std"),
            latitude=("latitude", "first"),
            longitude=("longitude", "first"),
        )
        .reset_index()
    )
    daily["sea_level_std"] = daily["sea_level_std"].fillna(0.0)

    daily.sort_values(["station_name", "date"], inplace=True)
    daily.reset_index(drop=True, inplace=True)

    g = daily.groupby("station_name")["sea_level"]

    daily["sea_level_3d_mean"] = g.transform(lambda x: x.rolling(3, min_periods=1).mean())
    daily["sea_level_7d_mean"] = g.transform(lambda x: x.rolling(7, min_periods=1).mean())
    daily["sea_level_14d_mean"] = g.transform(lambda x: x.rolling(14, min_periods=1).mean())

    daily["sea_level_3d_std"] = g.transform(lambda x: x.rolling(3, min_periods=1).std()).fillna(0.0)
    daily["sea_level_14d_std"] = g.transform(lambda x: x.rolling(14, min_periods=1).std()).fillna(0.0)

    daily["sea_level_14d_max"] = g.transform(lambda x: x.rolling(14, min_periods=1).max())
    daily["sea_level_14d_min"] = g.transform(lambda x: x.rolling(14, min_periods=1).min())
    daily["sea_level_14d_range"] = daily["sea_level_14d_max"] - daily["sea_level_14d_min"]

    daily["sea_level_trend7"] = g.transform(lambda x: (x - x.shift(6)) / 6.0).fillna(0.0)

    daily["sea_level_diff1"] = g.transform(lambda x: x.diff()).fillna(0.0)
    daily["sea_level_diff7"] = g.transform(lambda x: x.diff(7)).fillna(0.0)

    dt = pd.to_datetime(daily["date"])
    daily["doy"] = dt.dt.dayofyear.astype(int)
    daily["doy_sin"] = np.sin(2.0 * np.pi * daily["doy"] / 365.25)
    daily["doy_cos"] = np.cos(2.0 * np.pi * daily["doy"] / 365.25)
    daily["month"] = dt.dt.month.astype(int)
    daily["weekday"] = dt.dt.weekday.astype(int)

    stats = (
        daily.groupby("station_name")["sea_level"]
        .agg(["mean", "std"])
        .rename(columns={"mean": "st_mean", "std": "st_std"})
        .reset_index()
    )
    stats["st_std"] = stats["st_std"].fillna(0.0)
    daily = daily.merge(stats, on="station_name", how="left")
    daily["sea_level_anom"] = (daily["sea_level"] - daily["st_mean"]) / (daily["st_std"] + 1e-9)

    daily.sort_values(["station_name", "date"], inplace=True)
    daily.reset_index(drop=True, inplace=True)
    return daily

def add_station_onehot_vec(station_name, station_names):
    v = np.zeros((len(station_names),), dtype=np.float32)
    try:
        i = station_names.index(station_name)
        v[i] = 1.0
    except Exception:
        pass
    return v

def build_X_for_index(daily, index_df, per_day_feats, station_names, hist_days, future_days):
    n = len(index_df)
    d_win = hist_days * len(per_day_feats)
    d_extra = 4 + len(station_names)  # st_mean st_std lat lon + onehot
    D = d_win + d_extra

    X = np.zeros((n, D), dtype=np.float32)
    ok = np.zeros(n, dtype=bool)

    idx = index_df.copy()
    idx["hist_start"] = pd.to_datetime(idx["hist_start"]).dt.floor("D")
    idx["future_start"] = pd.to_datetime(idx["future_start"]).dt.floor("D")

    for stn, gidx in idx.groupby("station_name"):
        grp = daily[daily["station_name"] == stn].sort_values("date").reset_index(drop=True)
        if len(grp) < hist_days + future_days:
            continue

        dates = pd.to_datetime(grp["date"]).dt.floor("D").to_numpy()
        date_to_pos = {pd.Timestamp(d).to_pydatetime().date(): i for i, d in enumerate(dates)}

        F = grp[per_day_feats].to_numpy(dtype=np.float32)
        st_mean = grp["st_mean"].to_numpy(dtype=np.float32)
        st_std = grp["st_std"].to_numpy(dtype=np.float32)
        lat = grp["latitude"].to_numpy(dtype=np.float32)
        lon = grp["longitude"].to_numpy(dtype=np.float32)

        max_i = len(grp) - hist_days - future_days + 1
        st_ohe = add_station_onehot_vec(stn, station_names)

        for ridx, row in gidx.iterrows():
            hs = row["hist_start"]
            fs = row["future_start"]
            if pd.isna(hs) or pd.isna(fs):
                continue

            hs_key = hs.to_pydatetime().date()
            fs_key = fs.to_pydatetime().date()
            if hs_key not in date_to_pos or fs_key not in date_to_pos:
                continue

            i = date_to_pos[hs_key]
            j = date_to_pos[fs_key]

            # must satisfy future_start = hist_start + hist_days
            if j != i + hist_days:
                continue
            if i < 0 or i >= max_i:
                continue

            hist_block = F[i:i + hist_days, :]
            if not np.isfinite(hist_block).all():
                continue

            x_flat = hist_block.reshape(-1)
            x_extra = np.concatenate([np.array([st_mean[i], st_std[i], lat[i], lon[i]], dtype=np.float32), st_ohe])
            X[ridx, :] = np.concatenate([x_flat, x_extra])
            ok[ridx] = True

    return X, ok

def load_boosters(payload):
    if not HAS_XGB:
        raise RuntimeError("xgboost not available in inference environment.")

    model_jsons = payload.get("model_jsons", [])
    if not model_jsons:
        raise RuntimeError("model.pkl missing model_jsons")

    boosters = []
    for s in model_jsons:
        bst = xgb.Booster()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tf:
            tf.write(s)
            tmp_path = tf.name
        try:
            bst.load_model(tmp_path)
        finally:
            try:
                os.remove(tmp_path)
            except Exception:
                pass
        boosters.append(bst)
    return boosters

def main():
    input_dir = os.environ.get("INPUT_DIR", "/app/input_data")
    output_dir = os.environ.get("OUTPUT_DIR", "/app/output")
    submission_dir = os.environ.get("SUBMISSION_DIR", "/app/ingested_program")

    if not os.path.isdir(input_dir):
        input_dir = "."
    if not os.path.isdir(output_dir):
        output_dir = "."
    if not os.path.isdir(submission_dir):
        submission_dir = "."

    model_path = os.path.join(submission_dir, "model.pkl")
    if not os.path.exists(model_path):
        model_path = "model.pkl"

    test_hourly = os.path.join(input_dir, "test_hourly.csv")
    test_index = os.path.join(input_dir, "test_index.csv")
    pred_path = os.path.join(output_dir, "predictions.csv")

    print("[model] Loading model.pkl...", flush=True)
    with open(model_path, "rb") as f:
        payload = pickle.load(f)

    hist_days = int(payload.get("hist_days", 7))
    future_days = int(payload.get("future_days", 14))
    per_day_feats = payload.get("per_day_features", None)
    station_names = payload.get("station_names", None)
    calib_bias = float(payload.get("calib_bias", 0.0))

    if per_day_feats is None or station_names is None:
        raise KeyError("model.pkl missing per_day_features or station_names")

    print("[model] Reading test_hourly + test_index...", flush=True)
    df_te = pd.read_csv(test_hourly, parse_dates=["time"])
    idx = pd.read_csv(test_index)

    print("[model] Aggregating daily features...", flush=True)
    daily = hourly_to_daily(df_te)

    missing = [c for c in per_day_feats if c not in daily.columns]
    if missing:
        raise RuntimeError(f"Missing required daily feature columns: {missing}")

    print("[model] Building X for requested index...", flush=True)
    X, ok = build_X_for_index(daily, idx, per_day_feats, station_names, hist_days, future_days)

    y_prob = np.full((len(idx),), 0.5, dtype=np.float32)
    ok_idx = np.where(ok)[0]

    if len(ok_idx) > 0:
        boosters = load_boosters(payload)
        dte = xgb.DMatrix(X[ok_idx, :])

        probs = []
        for b in boosters:
            probs.append(b.predict(dte).astype(np.float32))
        p_ens = np.mean(np.column_stack(probs), axis=1)

        # calibration shift
        p_adj = sigmoid(logit(p_ens) + calib_bias).astype(np.float32)
        y_prob[ok_idx] = p_adj

    os.makedirs(output_dir, exist_ok=True)
    out = pd.DataFrame({"id": idx["id"].values, "y_prob": y_prob})
    out.to_csv(pred_path, index=False)
    print(f"[model] Wrote {pred_path} rows={len(out)} ok={int(ok.sum())}", flush=True)

if __name__ == "__main__":
    main()
